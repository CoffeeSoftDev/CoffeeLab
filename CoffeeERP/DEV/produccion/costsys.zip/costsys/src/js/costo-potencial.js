window.ctrl_costo_potencial =
  window.ctrl_costo_potencial || "ctrl/ctrl-costo-potencial.php";

$(function () {

  let datos = new FormData();

  datos.append("opc", "listUDN");

  send_ajax(datos, ctrl_costo_potencial).then((data) => {

    $("#txtUDN").option_select({ data: data });
    lsClase();

    $("#txtMes").val(3);
});

});

function lsClase() {
    datos = _get_data_opc(['UDN'], "lsClase");

     simple_send_ajax(datos, ctrl_costo_potencial).then((data) => {
       $("#txtClase").option_select({ data: data });
     });
}

function lsCostoPotencial() {

  datos = _get_data_opc(['UDN','Anio','Mes','Clase'], "lsCostoPotencial");
 

  fn_ajax(datos, ctrl_costo_potencial, "#tbDatos").then((data) => {
    
    $("#tbDatos").rpt_json_table2({
        data     : data,
        color_group    : 'bg-default',
        color_th : 'bg-primary',
        color_col: [3,4],
        color    : 'bg-default',
        right    : [3,4,6,8,9,10,11,12],
        center:[5,7],
    });
  });

}





function updateModal(id, title) {
  bootbox
    .dialog({
      title: ` EDITAR "${title.toUpperCase()}" `,
      message: `
                            <form id="modalForm" novalidate>
                                <div class="col-12 mb-3">
                                    <label for="cbModal" class="form-label fw-bold">Select</label>
                                    <div class="input-group-addon">
                                        <select class="form-select text-uppercase" name="cbModal" id="cbModal"></select>
                                    </div>
                                </div>
                              <div class="col-12 mb-3">
                                  <label for="iptModal" class="form-label fw-bold">Input</label>
                                  <input type="text" class="form-control" name="iptModal" id="iptModal" value="${title}" required>
                                  <span class="form-text text-danger hide">
                                      <i class="icon-warning-1"></i>
                                      El campo es requerido.
                                  </span>
                              </div>
                              <div class="col-12 mb-3 d-flex justify-content-between">
                                  <button type="submit" class="btn btn-primary col-5">Actualizar</button>
                                  <button type="button" class="btn btn-outline-danger col-5 bootbox-close-button">Cancelar</button>
                              </div>
                            </form>
                          `,
    })
    .on("shown.bs.modal", function () {
      const opciones = [
        { id: 1, valor: "Uno" },
        { id: 2, valor: "Dos" },
        { id: 3, valor: "Tres" },
      ];
      $("#cbModal").option_select({
        data: opciones,
        select2: true,
        father: true,
        placeholder: "- Seleccionar -",
      });

      let datos = $("#modalForm").validation_form({ id: id, opc: "update" });
      for (x of datos) {
        console.log(x);
      }

      // send_ajax(datos,ctrl_costo_potencial).then(data=>{
      //     alert();
      // });
    });
}

function toggleStatus(id) {
  const BTN = $("#btnStatus" + id);
  const ESTADO = BTN.attr("estado");

  let estado = 0;
  let iconToggle = '<i class="icon-toggle-off"></i>';
  let question = "¿DESEA DESACTIVARLO?";
  if (ESTADO == 0) {
    estado = 1;
    iconToggle = '<i class="icon-toggle-on"></i>';
    question = "¿DESEA ACTIVARLO?";
  }

  swal_question(question).then((result) => {
    if (result.isConfirmed) {
      //let datos = new FormData();
      //datos.append('opc','');
      //send_ajax(datos,ctrl_costo_potencial).then((data)=>{
      // console.log(data);
      BTN.html(iconToggle);
      BTN.attr("estado", estado);
      //});
    }
  });
}
