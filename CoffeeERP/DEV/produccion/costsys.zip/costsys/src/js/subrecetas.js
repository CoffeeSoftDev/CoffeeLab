window.ctrlSubrecetas = window.ctrlSubrecetas || "ctrl/ctrl-subrecetas.php";

function bodySubreceta() {
  $("#containerButtonAdd").html(
    `<label col="col-12 d-none d-md-block"> </label>
    <button type="button" class="btn btn-primary col-12" id="btnAddSubReceta" title="Nueva SubReceta">
        <i class="icon-plus"></i> Subreceta
    </button>`
  );
  $(".clasificacion-select").removeClass("hide");
  $("#btnAddSubReceta").on("click", function () {
    alert({
      icon: "question",
      title:
        "¿Desea agregar una nueva subreceta a " +
        $("#txtcbUDN option:selected").text() +
        " con clasificación " +
        $("#txtcbClasificacion option:selected").text() +
        "?",
    }).then((result) => {
      if (result.isConfirmed) {
        addSubRecetaInterface();
      }
    });
  });
  lsSubrecetas();
  $("#photo-subreceta").change(function () {
    photoSubReceta();
  });
}
// INTERFACES ------------------------------------------------------------
function addSubRecetaInterface() {
  $("#titleSubReceta").text(
    "Nueva subreceta / " + $("#txtcbUDN option:selected").text().toLowerCase()
  );
  $("#containerCatalogo").addClass("hide");
  $("#btnCreateSubReceta").text("Crear receta");
  $("#btnCreateSubReceta").removeClass("hide");
  $(".main-sub").addClass("hide");
  $(".secondary-sub").removeClass("hide");
  $("#fillSubReceta").addClass("hide");
  $("#btnSaveSubReceta").addClass("hide");
  $("#txtSubReceta").prop("disabled", false);
  $("#textareaNotasSub").prop("disabled", false);
  $("#txtcbClasificacionSub").prop("disabled", false);
  $("#txtSubReceta").val("");
  $("#textareaNotasSub").val("");
  $("#txtSubReceta").focus();
  $("formAddSubReceta button[type='submit']").removeAttr("disabled");
  $("formProcedimientoCulinarioSub button[type='submit']").removeAttr(
    "disabled"
  );
  $("#formAddSubRecetasIng button[type='submit']").removeAttr("disabled");
  $("#formAddSubRecetasSub button[type='submit']").removeAttr("disabled");
  $("#formAddSubReceta :input.is-invalid").removeClass("is-invalid");
  $("imgSubReceta").attr(
    "src",
    "https://minuspain.cl/wp-content/uploads/2021/09/default-placeholder-1.png"
  );

  $("#txtcbClasificacionSub").val(
    $("#txtcbClasificacion option:selected").val()
  );

  subrecipe("create", null);
}

function editSubRecetaInterface(id) {
  $("#titleSubReceta").text(
    "Editar subreceta / " + $("#txtcbUDN option:selected").text().toLowerCase()
  );
  $("#containerCatalogo").addClass("hide");
  $("#btnCreateSubReceta").text("Actualizar subreceta");
  $("#btnCreateSubReceta").removeClass("hide");
  $(".main-sub").addClass("hide");
  $(".secondary-sub").removeClass("hide");
  $("#fillSubReceta").removeClass("hide");
  $("#btnSaveSubReceta").addClass("hide");
  $("#txtSubReceta").prop("disabled", false);
  $("#textareaNotasSub").prop("disabled", false);
  $("#txtcbClasificacionSub").prop("disabled", false);
  $("#txtSubReceta").val("");
  $("#textareaNotasSub").val("");
  $("#txtSubReceta").focus();

  $("formAddSubReceta button[type='submit']").removeAttr("disabled");
  $("formProcedimientoCulinarioSub button[type='submit']").removeAttr(
    "disabled"
  );
  $("#formAddSubRecetasIng button[type='submit']").removeAttr("disabled");
  $("#formAddSubRecetasSub button[type='submit']").removeAttr("disabled");
  $("#formAddSubReceta :input.is-invalid").removeClass("is-invalid");

  // Obtener data de ingredientes y subrecetas para select
  let dataIng = updateDataIngredientes();
  let dataSubreceta = updateDataSubRecetas(
    dataSub.find((x) => x.id == id).idclasificacion
  );

  // Recuperar datos de la subreceta
  let foto = dataSub.find((x) => x.id == id).foto;
  if (foto !== null && foto !== "" && foto !== undefined) {
    $("#imgSubReceta").attr("src", "https://www.erp-varoch.com/" + foto);
  } else {
    $("#imgSubReceta").attr(
      "src",
      "https://minuspain.cl/wp-content/uploads/2021/09/default-placeholder-1.png"
    );
  }
  $("#txtSubReceta").val(dataSub.find((x) => x.id == id).valor);
  $("#textareaNotasSub").val(dataSub.find((x) => x.id == id).nota);
  $("#txtcbClasificacionSub").val(
    dataSub.find((x) => x.id == id).idclasificacion
  );

  subrecipe("edit", id);
  culinaryProcedureSubReceta("edit", id);
  ingredientsAndSubRecetaSubReceta(id, dataIng, dataSubreceta);
}

function subrecipe(param, id) {
  // Mayúsculas en el input de subrecetas
  $("#txtSubReceta").on("input", function () {
    this.value = this.value.toUpperCase();
  });

  // Agregar/Editar subrecetas
  $("#formAddSubReceta").validation_form({}, async function (result) {
    $("#formAddSubReceta button[type='submit']").attr("disabled", "disabled");
    let idSubReceta = param === "create" ? null : id; // Obtener el ID según la condición
    let udn =
      param === "create"
        ? $("#txtcbUDN").val()
        : dataSub.find((x) => x.id == id).idudn;

    let confirmarGuardado = await validateSubReceta(idSubReceta, udn);

    if (confirmarGuardado) {
      if (param === "create") {
        addSubReceta();
      } else {
        editSubReceta(id);
      }
    } else {
      $("#formAddSubReceta button[type='submit']").removeAttr("disabled");
    }
  });

  // Cerrar interfaz
  $("#btnCloseSubReceta").on("click", function () {
    let alert_close_subreceta = "";
    if (param === "create") {
      alert_close_subreceta = alert({
        icon: "question",
        title: "¿Desea regresar a la página principal?",
        text: "Los datos que no han sido guardados perderán.",
      });
    } else {
      alert_close_subreceta = alert({   
        icon: "question",
        title: "¿Desea terminar de editar esta subreceta?",
        text: "Los cambios no guardados se perderán.",
      });
    }

    alert_close_subreceta.then((result) => {
      if (result.isConfirmed) {
        $("#btnAddSubReceta").removeClass("hide");
        $(".main-sub").removeClass("hide");
        $(".secondary-sub").addClass("hide");
        $("#formAddSubReceta")[0].reset();
        $("#containerCatalogo").removeClass("hide");
        $("#containerFormProcCulinarioSub").html("");
        $("formAddSubReceta button[type='submit']").removeAttr("disabled");
        $("formProcedimientoCulinarioSub button[type='submit']").removeAttr(
          "disabled"
        );
        $("#formAddSubRecetasIng button[type='submit']").removeAttr("disabled");
        $("#formAddSubRecetasSub button[type='submit']").removeAttr("disabled");
        $("#formAddSubReceta :input.is-invalid").removeClass("is-invalid");
        $("#imgSubReceta").attr(
          "src",
          "https://minuspain.cl/wp-content/uploads/2021/09/default-placeholder-1.png"
        );
        lsSubrecetas();
      }
    });
  });
}

function culinaryProcedureSubReceta(param, id) {
  // PROCEDIMIENTO CULINARIO
  let json_form_proc_culinario_sub = [];
  if (param === "create") {
    json_form_proc_culinario_sub = [
      {
        opc: "input-group",
        lbl: "Total ingredientes",
        icon: "icon-dollar",
        tipo: "cifra",
        id: "TotalIngredientesSub",
        placeholder: "0.00",
        disabled: true,
        required: false,
      },
      {
        opc: "select",
        lbl: "Unidad",
        id: "UnidadSub",
        required: true,
      },
      {
        opc: "input-group",
        lbl: "Rendimiento",
        icon: "icon-hash",
        tipo: "cifra",
        id: "RendimientoSub",
        placeholder: "0.00",
        required: true,
      },
      {
        opc: "input-group",
        lbl: "Costo",
        icon: "icon-dollar",
        tipo: "cifra",
        id: "CostoSub",
        placeholder: "0.00",
        disabled: true,
        required: false,
      },
    ];
  } else {
    json_form_proc_culinario_sub = [
      {
        opc: "input-group",
        lbl: "Total ingredientes",
        icon: "icon-dollar",
        tipo: "cifra",
        id: "TotalIngredientesSub",
        placeholder: "0.00",
        disabled: true,
        required: false,
        value: dataSub.find((x) => x.id == id).totalIng,
      },
      {
        opc: "select",
        lbl: "Unidad",
        id: "UnidadSub",
        required: true,
        // value: dataSub.find((x) => x.id == id).idunidad,
      },
      {
        opc: "input-group",
        lbl: "Rendimiento",
        icon: "icon-hash",
        tipo: "cifra",
        id: "RendimientoSub",
        placeholder: "0.00",
        required: true,
        value: dataSub.find((x) => x.id == id).rendimiento,
      },
      {
        opc: "input-group",
        lbl: "Costo",
        icon: "icon-dollar",
        tipo: "cifra",
        id: "CostoSub",
        placeholder: "0.00",
        disabled: true,
        required: false,
        value: dataSub.find((x) => x.id == id).costo,
      },
    ];
  }
  let form_proc_sub = $("<form>", {
    id: "formProcedimientoCulinarioSub",
    class: "row row-cols-1",
    novalidate: true,
  });
  // Crear el formulario
  form_proc_sub.html("").simple_json_form({
    data: json_form_proc_culinario_sub,
    name_btn: "Guardar Procedimiento",
  });
  // Anexar el formulario al contenedor
  $("#containerFormProcCulinarioSub").html("");
  form_proc_sub.appendTo("#containerFormProcCulinarioSub");
  // Cargar datos en el select unidad
  $("#txtUnidadSub").option_select({
    data: dataCatalogo.unidad,
    select2: true,
    group: false,
    placeholder: "Selecciona una unidad",
  });
  if (param === "edit") {
    $("#txtUnidadSub").val(dataSub.find((x) => x.id == id).idunidad).trigger("change");
  }
    
  // Validation form procedimiento culinario
  $("#formProcedimientoCulinarioSub").validation_form({}, function (result) {
    $("#formProcedimientoCulinarioSub button[type='submit']").attr(
      "disabled",
      "disabled"
    );
    addProcedimientoCulinarioSub(id);
  });
}

function ingredientsAndSubRecetaSubReceta(id, dataIng, dataSubreceta) {
    console.log(id);
  // Objeto para la tabla
  let object_table = {
    f_size: "14",
    color_th: "bg-primary",
    ipt: [3],
  };

  // INGREDIENTES
  let json_form_sub_ing = [
    {
      opc: "btn",
      class: "float-end",
      btn_class: "btn-close",
      fn: "closeForm('#formAddSubRecetasIng', '#contentTableSubRecetasIng', '#addSubRecetasIng')",
    },
    {
      opc: "select",
      lbl: "Ingrediente",
      id: "id_Ingrediente",
      class: "mt-4",
      required: true,
    },
    {
      opc: "input",
      lbl: "Cantidad",
      id: "cantidad",
      tipo: "cifra",
      placeholder: "0.00",
      required: true,
    },
  ];
  let dtx_sub_ing = {
    opc: "tbSubRecetaIngrediente",
    idSubReceta: id,
  };

  // Objetos para el modulo de ingredientes
  let object_frm_ing = {
    id_Subreceta: id,
    opc: "createSubRecetaIngrediente",
  };
  let object_event_ing = {
    opc: "updateSubRecetaIngrediente",
    id_Subreceta1: id,
  };
  let object_attr_json_frm_ing = {
    name_btn: "Agregar Ingrediente",
  };
  let object_alert_ing = {
    icon: "success",
    title: "Ingrediente",
    text: "Ingrediente guardado correctamente",
  };

  // Modulo subrecetas-ingredientes
  $("#frmAndTbSubRecetasIng").modulo_1({
    json_frm: json_form_sub_ing,
    datos: dtx_sub_ing,
    enlace: ctrlSubrecetas,
    content_table: "contentTableSubRecetasIng",
    frm: "formAddSubRecetasIng",
    table: "tbSubRecetasIng",
    class_frm: "col-12 col-md-4",
    class_formulario: "col-12  container-border-right container-border-info",
    class_table: "col-12 col-md-8",
    atributos_table: object_table,
    atributos_frm: object_frm_ing,
    atributos_alert: object_alert_ing,
    atributos_event: object_event_ing,
    attr_json_frm: object_attr_json_frm_ing,
    // fn: calcularProcedimientoCulinario(),
  });

  // Cargar datos en el select ingredientes
  $("#txtid_Ingrediente").option_select({
    data: dataIng,
    select2: true,
    group: false,
    placeholder: "Selecciona un ingrediente",
  });

  // SUBRECETAS
  let json_form_sub_sub = [
    {
      opc: "btn",
      class: "float-end",
      btn_class: "btn-close",
      fn: "closeForm('#formAddSubRecetasSub', '#contentTableSubRecetasSub', '#addSubRecetasSub')",
    },
    {
      opc: "select",
      lbl: "Subreceta",
      id: "id_Subreceta2",
      class: "mt-4",
      required: true,
    },
    {
      opc: "input",
      lbl: "Cantidad",
      id: "cantidad",
      tipo: "cifra",
      placeholder: "0.00",
      required: true,
    },
  ];
  let dtx_sub_sub = {
    opc: "tbSubRecetaSubReceta",
    idSubReceta: id,
  };

  // Objetos para el modulo de subrecetas
  let object_frm_sub = {
    id_Subreceta1: id,
    opc: "createSubRecetaSubReceta",
  };
  let object_event_sub = {
    opc: "updateSubRecetaSubReceta",
    id_Subreceta1: id,
  };
  let object_attr_json_frm_sub = {
    name_btn: "Agregar Subreceta",
  };
  let object_alert_sub = {
    icon: "success",
    title: "Subreceta",
    text: "Subreceta guardada correctamente",
  };

  // Modulo subrecetas-subrecetas
  if (dataSubreceta.length > 0) {
    $("#frmAndTbSubRecetasSub").modulo_1({
      json_frm: json_form_sub_sub,
      datos: dtx_sub_sub,
      enlace: ctrlSubrecetas,
      content_table: "contentTableSubRecetasSub",
      frm: "formAddSubRecetasSub",
      table: "tbSubRecetasSub",
      class_frm: "col-12 col-md-4",
      class_formulario: "col-12  container-border-right container-border-info",
      class_table: "col-12 col-md-8",
      atributos_table: object_table,
      atributos_frm: object_frm_sub,
      atributos_alert: object_alert_sub,
      atributos_event: object_event_sub,
      attr_json_frm: object_attr_json_frm_sub,
    });
  }
  // Cargar datos en el select subrecetas
  $("#txtid_Subreceta2").option_select({
    data: dataSubreceta,
    select2: true,
    group: false,
    placeholder: "Selecciona una subreceta",
  });
  // Cargar el select de subrecetas de acuerdo a la clasificación
  $("#txtcbClasificacionSub").on("change", function () {
    let dataSub = updateDataSubRecetas($(this).val());
    $("#txtid_Subreceta2").html("");
    $("#txtid_Subreceta2").option_select({
      data: dataSub,
      select2: true,
      group: false,
      placeholder: "Selecciona una subreceta",
    });
  });

  // Estilos
  // Ingredientes
  $("#formAddSubRecetasIng").parent().addClass("p-0 m-0");
  $("#formAddSubRecetasIng")
    .children()
    .eq(3)
    .removeClass("mb-3")
    .addClass("mb-2");
  $("#formAddSubRecetasIng button[type='submit']")
    .removeClass("mt-4")
    .addClass("mt-3");
  // Subrecetas
  $("#formAddSubRecetasSub").parent().addClass("p-0 m-0");
  $("#formAddSubRecetasSub")
    .children()
    .eq(3)
    .removeClass("mb-3")
    .addClass("mb-2");
  $("#formAddSubRecetasSub button[type='submit']")
    .removeClass("mt-4")
    .addClass("mt-3");
  // Procedimiento culinario
  $("#formProcedimientoCulinarioSub button[type='submit']")
    .removeClass("mt-4")
    .addClass("mt-3");
}

// SUBRECETA ------------------------------------------------------------
async function validateSubReceta(id, udn) {
  const confirmacionInicial = await alert({
    icon: "question",
    title: "¿Está seguro de guardar esta subreceta?",
  });

  if (!confirmacionInicial.isConfirmed) return false;

  const nameSubReceta = $("#txtSubReceta").val().toUpperCase().trim();

  let datos = new FormData();
  datos.append("opc", "validateSubReceta");
  datos.append("nombre", nameSubReceta);
  datos.append("udn", udn);

  // Validar si existe la subreceta
  data = await send_ajax(datos, ctrlSubrecetas);

  if (data && data.length > 0) {
    let nombres = "";
    let id_udn = "";
    let encontrado = false;

    data.forEach((element) => {
      nombres += element.nombre + ", ";
      id_udn = element.id_udn + ", ";
      if (element.id == id) {
        encontrado = true;
      }
    });

    if (encontrado) {
      return true;
    } else {
      let existe = data.some(
        (x) => x.nombre === nameSubReceta && x.id_udn === udn && x.id !== id
      );

      if (existe) {
        let confirmacionSimilar = await alert({
          icon: "question",
          title:
            "Se encontraron subrecetas relacionadas con este nombre ¿Deseas continuar?",
          text: "Subrecetas existentes:\n" + nombres,
        });
        if (confirmacionSimilar.isConfirmed) {
          alert({
            icon: "error",
            title: "Lo sentimos",
            text: `El nombre "${nameSubReceta}" ya existe, intente con otro nombre.`,
            btn1: true,
          });
          return false;
        } else {
          return false;
        }
      } else {
        console.log("Subreceta no existe");
        return true;
      }
    }
  }
  return true;
}

function addSubReceta() {
  let foto = $("#photo-receta")[0].files[0];

  let datos = new FormData();
  datos.append("opc", "createSubReceta");
  datos.append("nombre", $("#txtSubReceta").val());
  datos.append("id_Clasificacion", $("#txtcbClasificacionSub").val());
  datos.append("nota", $("#textareaNotasSub").val());
  datos.append("id_UDN", $("#txtcbUDN").val());
  datos.append("foto", foto);
  send_ajax(datos, ctrlSubrecetas).then((data) => {
    if (data !== false && data !== null && data !== "null") {
      alert({
        icon: "success",
        title: "Subreceta",
        text: "Subreceta creada correctamente",
      });
      $("#fillSubReceta").removeClass("hide");
      $("#txtSubReceta").prop("disabled", true);
      $("#txtcbClasificacionSub").prop("disabled", true);
      $("#btnCreateSubReceta").addClass("hide");
      $("#btnSaveSubReceta").removeClass("hide");
      $("#txtcbClasificacionSub").prop("disabled", true);
      $("#formAddSubReceta button[type='submit']").removeAttr("disabled");
      let dataIng = updateDataIngredientes();
      let dataSub = updateDataSubRecetas($("#txtcbClasificacionSub").val());
      culinaryProcedureSubReceta("create", data.idSubReceta);
      ingredientsAndSubRecetaSubReceta(data.idSubReceta, dataIng, dataSub);
      // Guardar datos de la subreceta
      $("#btnSaveSubReceta").on("click", function () {
        $("#textareaNotasSub").prop("disabled", false);
        alert({
          icon: "question",
          title: "¿Está seguro de guardar la subreceta?",
        }).then((result) => {
          if (result.isConfirmed) {
            editSubReceta(data.idSubReceta);
          }
        });
      });
    } else {
      alert({
        icon: "error",
        title: "Subreceta",
        text: "Error al guardar la subreceta",
      });
    }
  });
}

function editSubReceta(id) {
  let foto = $("#photo-subreceta")[0].files[0];

  let dtx = new FormData();
  dtx.append("opc", "updateSubReceta");
  dtx.append("nombre", $("#txtSubReceta").val());
  dtx.append("id_Clasificacion", $("#txtcbClasificacionSub").val());
  dtx.append("nota", $("#textareaNotasSub").val());
  dtx.append("rendimiento", $("#txtRendimientoSub").val());
  dtx.append("id_Unidad", $("#txtUnidadSub").val());
  dtx.append("foto", foto);
  dtx.append("idSubreceta", id);
  send_ajax(dtx, ctrlSubrecetas).then((data) => {
    if (data.idSubReceta !== null && data.idSubReceta !== "null" && data.idSubReceta !== "" && data.idSubReceta !== undefined) {
      alert({
        icon: "success",
        title: "Subreceta",
        text: "Guardado correctamente",
      });
      $("#formAddSubReceta button[type='submit']").removeAttr("disabled");
      // Cambiar datos de dataSub
      if (dataSub.find((x) => x.id == id) !== undefined) {
        dataSub.find((x) => x.id == id).valor = $("#txtSubReceta").val();
        dataSub.find((x) => x.id == id).idclasificacion = $(
          "#txtcbClasificacionSub"
        ).val();
        dataSub.find((x) => x.id == id).clasificacion = $(
          "#txtcbClasificacionSub option:selected"
        ).text();
        dataSub.find((x) => x.id == id).nota = $("#textareaNotasSub").val();
        dataSub.find((x) => x.id == id).rendimiento =
          $("#txtRendimientoSub").val();
        dataSub.find((x) => x.id == id).idunidad = $("#txtUnidadSub").val();
        dataSub.find((x) => x.id == id).foto = data.rutaFoto;
      } else {
        // Agregar a dataSub la nueva receta
        dataSub.push({
          id: id,
          valor: $("#txtSubReceta").val(),
          idclasificacion: $("#txtcbClasificacionSub").val(),
          clasificacion: $("#txtcbClasificacionSub option:selected").text(),
          nota: $("#textareaNotasSub").val(),
          rendimiento: $("#txtRendimientoSub").val(),
          idunidad: $("#txtUnidadSub").val(),
          foto: data.rutaFoto,
        });
      }
    } else {
      alert({
        icon: "error",
        title: "Subreceta",
        text: "Error al actualizar la subreceta",
      });
    }
  });
}

// SUBRECETAS - INGREDIENTES --------------------------------------------
function deleteSubRecetaIngrediente(
  btn,
  idSubReceta,
  idIngrediente,
  tb,
  itemCount,
  costTotal
) {
  alert({
    icon: "question",
    title: "¿Está seguro de eliminar este ingrediente?",
    text: "Será de forma permanente.",
  }).then((result) => {
    if (result.isConfirmed) {
      let datos = new FormData();
      datos.append("opc", "deleteSubRecetaIngrediente");
      datos.append("id_Subreceta", idSubReceta);
      datos.append("id_Ingrediente", idIngrediente);
      send_ajax(datos, ctrlSubrecetas).then((data) => {
        if (data === true) {
          alert({
            icon: "info",
            title: "Ingrediente",
            text: "Eliminado correctamente",
            btn1: true,
          });
          $(btn).closest("tr").remove();
          $(itemCount).text($(tb + " tbody tr").length);
          $(costTotal).text(addCostColumn(tb, 4));
        } else {
          alert({
            icon: "error",
            title: "Ingrediente",
            text: "Error al eliminar",
          });
        }
      });
    }
  });
}

// SUBRECETAS - SUBRECETAS ----------------------------------------------
function deleteSubRecetaSubReceta(
  btn,
  idReceta,
  idSubreceta,
  tb,
  itemCount,
  costTotal
) {
  alert({
    icon: "question",
    title: "¿Está seguro de eliminar esta subreceta?",
    text: "Será de forma permanente.",
  }).then((result) => {
    if (result.isConfirmed) {
      let datos = new FormData();
      datos.append("opc", "deleteSubRecetaSubReceta");
      datos.append("id_Subreceta1", idReceta);
      datos.append("id_Subreceta2", idSubreceta);
      send_ajax(datos, ctrlSubrecetas).then((data) => {
        if (data === true) {
          alert({
            icon: "info",
            title: "Subreceta",
            text: "Eliminada correctamente",
            btn1: true,
          });
          $(btn).closest("tr").remove();
          $(itemCount).text($(tb + " tbody tr").length);
          $(costTotal).text(addCostColumn(tb, 4));
        } else {
          alert({
            icon: "error",
            title: "Subreceta",
            text: "Error al eliminar",
          });
        }
      });
    }
  });
}

// PROCEDIMIENTO CULINARIO ----------------------------------------------
function addProcedimientoCulinarioSub(id) {
  let dtx = new FormData();
  dtx.append("opc", "procedimientoCulinarioSubReceta");
  dtx.append("rendimiento", $("#txtRendimientoSub").val());
  dtx.append("id_Unidad", $("#txtUnidadSub").val());
  dtx.append("idSubreceta", id);
  if (id === null || id === "null" || id === undefined) {
    alert({
      icon: "error",
      title: "Procedimiento culinario",
      text: "Error al guardar",
      timer: 1000,
    });
    $("#formProcedimientoCulinarioSub button[type='submit']").removeAttr(
      "disabled"
    );
  } else {
    send_ajax(dtx, ctrlSubrecetas).then((data) => {
      if (data === true) {
        $("#formProcedimientoCulinarioSub button[type='submit']").removeAttr(
          "disabled"
        );
        alert({
          icon: "success",
          title: "Procedimiento culinario",
          text: "Guardado correctamente",
        });
      } else {
        alert({
          icon: "error",
          title: "Procedimiento culinario",
          text: "Error al guardar",
        });
      }
    });
  }
}

// FUNCIONES ------------------------------------------------------------
function photoSubReceta() {
  let file = $("#photo-subreceta")[0].files[0];
  if (file) {
    $("#content_photo_subreceta span").css({ display: "flex" });
    $("#content_photo_subreceta span").html(
      '<i class="animate-spin icon-spin6"></i> Analizando'
    );
    setTimeout(() => {
      let reader = new FileReader();
      reader.readAsDataURL(file);
      $("#content_photo_subreceta span").hide();
      $("#content_photo_subreceta span").removeAttr("style");
      $("#content_photo_subreceta span").addClass("text-uppercase");
      $("#content_photo_subreceta span").html(
        '<i class="icon-camera"></i> Subir foto'
      );
      reader.onload = function (e) {
        $("#imgSubReceta").attr("src", e.target.result);
      };
    }, 500);
  }
}

function calcularProcedimientoCulinario() {
  console.log("Calculando procedimiento culinario");
  let totalIng = $("#tbSubRecetasIng tbody tr").length;

  let costo = addCostColumn("tbSubRecetasIng", 4);
  console.log("Costo total: " + costo);
  console.log("Total ingredientes: " + totalIng);

  //   let totalIng = $("#tbSubRecetasIng tbody tr").length;
  //   let totalIng = $("#lblTotalCostoSubRecetaIng").text();
  //   console.log("Total ingredientes: " + totalIng);

  $("#txtRendimientoSub").on("input", function () {
    let rendimiento = parseFloat($(this).val());
    let costo = addCostColumn("tbSubRecetasIng", 4);
    let precio = costo * rendimiento;
    let margenCon = precio - costo;
    let porcentaje = (costo / precio) * 100;

    $("#txtTotalIngredientesSub").text(totalIng);
    $("#txtCostoSub").text(costo.toFixed(2));
    $("#txtPrecioVentaSub").text(precio.toFixed(2));
    $("#txtMargenConSub").text(margenCon.toFixed(2));
    $("#txtPorcentajeCostoSub").text(porcentaje.toFixed(2));
  });
}
