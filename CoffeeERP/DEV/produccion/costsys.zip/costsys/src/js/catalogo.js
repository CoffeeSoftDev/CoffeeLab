window.ctrlCatalogo = window.ctrlCatalogo || "ctrl/ctrl-catalogo.php";
window.dataCatalogo = window.dataCatalogo || [];

$(function () {
  initComponents(ctrlCatalogo)
    .then((data) => {
      dataCatalogo = data;
      $("#txtcbUDN").option_select({ data: dataCatalogo.udn });
      updateClassification();
    })
    .then(() => {
      bodySubreceta();
      loadCatalog();
    });
});

function loadCatalog() {
  // Cargar el cuerpo de cada pestaña
  $("#ingredientes-tab").on("click", function () {
    $(".nav-item").removeClass("active");
    $(this).parent().addClass("active");
    $(".nav-link").removeClass("active");
    $(this).addClass("active");
    bodyIngrediente();
  });
  $("#subrecetas-tab").on("click", function () {
    $(".nav-item").removeClass("active");
    $(this).parent().addClass("active");
    $(".nav-link").removeClass("active");
    $(this).addClass("active");
    bodySubreceta();
  });
  $("#recetas-tab").on("click", function () {
    $(".nav-item").removeClass("active");
    $(this).parent().addClass("active");
    $(".nav-link").removeClass("active");
    $(this).addClass("active");
    bodyReceta();
  });

  // Cambio de select udn
  $("#txtcbUDN").on("change", function () {
    updateClassification();
    if ($("#subrecetas-tab").hasClass("active")) {
      lsSubrecetas();
    } else if ($("#recetas-tab").hasClass("active")) {
      lsRecetas();
    } else if ($("#ingredientes-tab").hasClass("active")) {
      lsIngredientes();
    }
  });
  // Cambio de select clasificación
  $("#txtcbClasificacion").on("change", function () {
    if ($("#subrecetas-tab").hasClass("active")) {
      lsSubrecetas();
    } else if ($("#recetas-tab").hasClass("active")) {
      lsRecetas();
    }
  });
}

function updateClassification() {
  // Actualizar clasificaciones de acuerdo a la UDN
  let clasificaciones = dataCatalogo.clasificacion.filter(
    (item) => item.udn === $("#txtcbUDN").val()
  );

  $("#txtcbClasificacion").option_select({ data: clasificaciones });
  $("#txtcbClasificacionSub").option_select({ data: clasificaciones });
  $("#txtcbClasificacionRec").option_select({ data: clasificaciones });
}

function updateSubclassifications(select) {
  let subclasificaciones = dataCatalogo.subclasificacion.filter(
    (item) => item.idclasificacion === select
  );
  return subclasificaciones;
}

function updateDataIngredientes() {
  let dataIngredientes = dataCatalogo.ingredientes.filter(
    (item) => item.idudn === $("#txtcbUDN").val()
  );
  return dataIngredientes;
}

function updateDataSubRecetas(select) {
  let dataSubreceta = dataCatalogo.subrecetas.filter(
    (item) => item.idclasificacion === select
  );
  return dataSubreceta;
}

// FUNCIONES UNIVERSALES
function unitPrice(precio, contNeto) {
  if ($(precio).val() != "" && $(contNeto).val() != "") {
    let price = parseFloat($(precio).val());
    let netContent = parseFloat($(contNeto).val());
    let precioUnidad = netContent == 0 ? 0 : price / netContent;
    return precioUnidad.toFixed(2);
  }
  return 0.0;
}

function closeForm(form, tb, btn) {
  $(form).addClass("hide");
  $(tb).removeClass("col-md-8");
  $(btn).removeClass("hide");
  $(form)[0].reset();
  $(form + " select")
    .val("")
    .trigger("change");
}

function openForm(form, tb, btn) {
  $(form).removeClass("hide");
  $(tb).addClass("col-md-8");
  $(btn).addClass("hide");
}

function addCostColumn(tb, col) {
  let total = 0;
  let totalFormat = 0;
  $(tb + " tbody tr").each(function () {
    total += parseFloat(
      $(this).find("td").eq(col).text().trim().substring(2).replace(/,/g, '')
    );
    console.log(total);
    totalFormat = total.toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  });

  return totalFormat;
}

function modalEditIngrediente(idIng, event, param) {
  let modalEditIngrediente = bootbox.dialog({
    title: ` ACTUALIZAR INGREDIENTE `,
    message: `
                <form class="row row-cols-1 row-cols-sm-3 row-cols-md-3" id="formEditIngrediente" novalidate>
                    <div class="col-sm-12 col-md-12 mb-3">
                        <label for="iptNombreIng" class="form-label fw-bold"> Nombre</label>
                        <input type="text" class="form-control form-control-sm col-12" id="iptNombreIng" value="${
                          dataCatalogo.ingredientes.find((x) => x.id == idIng)
                            .valor
                        }" tipo="alfanumerico" disabled>
                    </div>
                    <div class="col mb-3">
                        <label for="iptContenidoNetoIng" class="form-label fw-bold"> Contenido neto</label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i class="icon-hash"></i>
                            </span>
                            <input type="text" class="form-control text-end" id="iptContenidoNetoIng" placeholder="0" value="${
                              dataCatalogo.ingredientes.find(
                                (x) => x.id == idIng
                              ).neto
                            }" tipo="cifra" required/>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <label for="iptPrecioIng" class="form-label fw-bold"> Precio</label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i class="icon-dollar"></i>
                            </span>
                            <input type="text" class="form-control text-end" id="iptPrecioIng" placeholder="0" value="${
                              dataCatalogo.ingredientes.find(
                                (x) => x.id == idIng
                              ).costo
                            }" tipo="cifra" required/>
                        </div>
                    </div>
                    <div class="col mb-4">
                        <label for="iptPrecioUnidadIng" class="form-label fw-bold"> Precio por unidad</label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i class="icon-dollar"></i>
                            </span>
                            <input type="text" class="form-control text-end" id="iptPrecioUnidadIng" placeholder="0" value="${
                              dataCatalogo.ingredientes.find(
                                (x) => x.id == idIng
                              ).precioUnidad
                            }" disabled/>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-12 mb-3 d-flex justify-content-between">
                        <button class="btn btn-primary col-5" type="submit">Actualizar</button>
                        <button class="btn btn-outline-danger col-5 offset-2 bootbox-close-button col-5" id="btnCerrarModal">Cancelar</button>
                    </div>
                </form>
            `,
  });
  modalEditIngrediente.on("shown.bs.modal", function () {
    $("#formEditIngrediente button[type='submit']").removeAttr("disabled");
    $("#iptContenidoNetoIng").on("input", function () {
      $("#iptPrecioUnidadIng").val(
        unitPrice("#iptPrecioIng", "#iptContenidoNetoIng")
      );
    });

    $("#iptPrecioIng").on("input", function () {
      $("#iptPrecioUnidadIng").val(
        unitPrice("#iptPrecioIng", "#iptContenidoNetoIng")
      );
    });

    $("#formEditIngrediente").validation_form({}, function (result) {
      $("#formEditIngrediente button[type='submit']").attr(
        "disabled",
        "disabled"
      );
      let tr = $(event.target).closest("tr");
      let dtx = new FormData();
      dtx.append("opc", "createOrUpdateIngredientes");
      dtx.append("precio", $("#iptPrecioIng").val());
      dtx.append("contNeto", $("#iptContenidoNetoIng").val());
      dtx.append("idIngrediente", idIng);
      send_ajax(dtx, ctrlIngredientes).then((data) => {
        if (data === true) {
          alert({
            icon: "success",
            title: "Ingrediente",
            text: "Actualizado correctamente",
          });
          // Cambiar la data del arreglo
          dataCatalogo.ingredientes.find((x) => x.id == idIng).costo =
            $("#iptPrecioIng").val();
          dataCatalogo.ingredientes.find((x) => x.id == idIng).neto = $(
            "#iptContenidoNetoIng"
          ).val();
          dataCatalogo.ingredientes.find((x) => x.id == idIng).precioUnidad = $(
            "#iptPrecioUnidadIng"
          ).val();
          let input = $(tr).find("td").eq(2).find("input").val();
          let precioUnidad = $("#iptPrecioUnidadIng").val();
          // Cambiar la data de la tabla
          $(tr)
            .find("td")
            .eq(3)
            .text("$ " + $("#iptPrecioUnidadIng").val());
          $(tr)
            .find("td")
            .eq(4)
            .text("$ " + (input * precioUnidad).toFixed(2));
          // Cambiar la data del total
          let tb = "#" + tr.closest("table").attr("id");

          if (param == "receta") {
            $("#lblTotalCostoRecetaIng").text(addCostColumn(tb, 4));
            changeCulinaryProcedureReceta();
          } else {
            $("#lblTotalCostoSubRecetaIng").text(addCostColumn(tb, 4));
            changeCulinaryProcedureSubReceta();
          }
          modalEditIngrediente.modal("hide");
        } else {
          alert({
            icon: "error",
            title: "Ingrediente",
            text: "Error al actualizar",
          });
        }
      });
    });
  });
}
