<?php
require_once('../../conf/_CRUD.php');

class Costopotencial extends CRUD{
    private $bd;
    public function __construct()
    {
        $this->bd3 = 'rfwsmqex_gvsl_costsys.';
        $this->bd2 = 'rfwsmqex_gvsl_costsys2.';
        $this->bd = 'costsys_';
    }

    function selectSumatoriasEstimadas($array) {
        $query = "SELECT
                        SUM(ventasestimadas) AS ventasestimada,
                        SUM(costoestimado) AS costoestimado,
                        SUM(mc_estimado) AS mc_estimado,
                        SUM(ventasestimadas_propuesto) AS ventasestimadas_propuesto,
                        SUM(costoestimado_propuesto) AS costoestimado_propuesto,
                        SUM(mcestimado_propuesto) AS mcestimado_propuesto,
	                    SUM(desplazamiento) AS desplazamiento,
	                    COUNT(idcostopotencial) AS produccion
                    FROM
                        {$this->bd2}costopotencial 
                    WHERE
                        desplazamiento != 0 
                        AND id_Clasificacion = ?
                        AND YEAR (fecha_costo) = ? 
                        AND MONTH (fecha_costo) = ? ";
        $sql = $this->_Read($query, $array);
        $row = null;
        foreach ($sql as $row);
        return $row;
    }


    function lsUDN(){
        $query ="SELECT idUDN AS id, UDN AS valor 
        FROM udn WHERE Stado = 1  ORDER BY Antiguedad ASC ";
        return $this->_Read($query, null);
    }

    function lsClase($array){

        $query ="
            SELECT idClasificacion as id, Clasificacion as valor 
            FROM   costsys_clasificacion 
            WHERE  Stado = 1 
            AND id_UDN = ?
        ";

        return $this->_Read($query, $array);

    }

    function selectSubclasificaciones($idClasificacion){
        $array = array($idClasificacion);
        $query = "SELECT * FROM costsys_subclasificacion WHERE id_Clasificacion = ? 
        AND (costsys_subclasificacion.nombre != 'DESCONTINUADO' 
        AND costsys_subclasificacion.nombre != 'PRODUCTOS CON EMPAQUE') ORDER BY nombre ASC";
        $sql = $this->_Read($query,$array);
    
        return $sql;
    }

    function selectRecetasSubclasificacionNull($idClasificacion) {
    $array = array($idClasificacion);
    
    $query = "
    SELECT * FROM 
      costsys_recetas 
    WHERE id_Clasificacion = ? 
    AND id_Subclasificacion IS NULL 
    ORDER BY nombre ASC";

    $sql = $this->_Read($query,$array);
    return $sql;
    }

function selectRecetasSubclasificacion($idSubclasificacion) {
    $array = array($idSubclasificacion);
    $query = "SELECT * FROM costsys_recetas 
    WHERE id_Subclasificacion = ? ORDER BY nombre ASC";
    $sql = $this->_Read($query,$array);
    return $sql;
}


function selectDatosCostoPotencial($a){
    // $array = array($idReceta,$mes,$year);
    $query = "
    SELECT * FROM {$this->bd3}costopotencial 
    
    WHERE receta = ? 
    
    AND MONTH(fecha_costo) = ? 
    AND YEAR(fecha_costo)  = 2023";
    
    $sql = $this->_Read($query,$a);
    $row = null;
    foreach($sql as $row);
    return $row;
}




/* Existe el tablero creado */ 

    function Tabla_costoPotencial($arreglo){
        
        
        $query = "
        SELECT
        *
        FROM
        {$this->bd3}costopotencial
        WHERE
        MONTH (fecha_costo) = ?
        AND YEAR (fecha_costo) = ?
        AND id_Clasificacion = ?
        ";

        $sql = $this->_Read($query, $arreglo);
        
        return $sql;
    }
    function lsCostoPotencialReceta($arreglo){
        
        
        $query = "
        SELECT
        recetas.idReceta,
        recetas.nombre,
        recetas.precioVenta,
        recetas.rendimiento,
        precio_propuesto,
        desplazamiento,
        costopotencial.iva,
        recetas.ieps,
        costopotencial.idcostopotencial,
        recetas.id_Clasificacion,
        recetas.id_Subclasificacion
        FROM
        {$this->bd3}costopotencial,
        {$this->bd3}recetas
        WHERE
        receta = idReceta
        AND MONTH (fecha_costo) = ?
        AND YEAR (fecha_costo) = ?
        AND costopotencial.id_Clasificacion = ?

       -- LIMIT 10
        ";

        $sql = $this->_Read($query, $arreglo);
        
        return $sql;
    }

    function selectTablero($idClasificacion, $mes, $year){
        $array = array($idClasificacion, $mes, $year);
        
        $query = "SELECT * FROM {$this->bd3}tablerocontrol 
        WHERE id_Clasificacion = ? 
        AND MONTH(fechaMovimiento) = ? 
        AND YEAR(fechaMovimiento) = ?";
        $sql = $this->_Read($query, $array);
        $row = null;
        foreach ($sql as $row) ;
        return $row;
    }



    function calculoCostoPotencial($data,$calculo){

        $permiso = 1;

        $impuestos = $data['iva'] + $data['ieps'];
        $pVentaIVA = $data['pVenta'] / (1 + ($impuestos / 100));

        $receta = $calculo->totalReceta($data['idReceta']);
        
        $total = $receta['totalReceta'];
        
        
        $costo = $total / $data['rendimiento'];

        $mc = $pVentaIVA - $costo;
        $porcentajeCosto = ($costo / $pVentaIVA) * 100;

        $ventasEstimadas = $pVentaIVA * $data['desplazamiento'];
        $costoEstimado = $costo * $data['desplazamiento'];
        $mcEstimado = $mc * $data['desplazamiento'];

        // --- .Calculo propuesto . ---
        $yearAnterior = $_POST['Anio'];
        $mesAnterior  = $_POST['Mes'];
        
        if ($_POST['Mes'] == 1) {
            $mesAnterior = 12;
            $yearAnterior = $_POST['Anio'] - 1;
        }

        $cpAnterior = $this->selectDatosCostoPotencial([
            $data['idReceta'],
            $mesAnterior]);

        $ls = count($cpAnterior);





        if ($data['desplazamiento'] == 0 && $permiso == 1) {
            $desplazamiento = $cpAnterior['desplazamiento'];
        }

         if ( $data['precioPropuesto'] != 0 ):

         else: 
         
         if(isset($cpAnterior['precio_propuesto']) && $cpAnterior['precio_propuesto'] != 0 && $permiso == 1):

            $pPropuesto = $cpAnterior['precio_propuesto'];
        
         else:

            $pPropuesto = 0;
            $mcPropuesto = 0;
            $porcentajeCostoPropuesto = 0; 
            
            

         endif;

        endif;


        // -- aplicar filtros modificables --
        $desplazamientoPromedio = 0;
        $costoAlto = 0;
        $costoBajo = 0;
        $mcAlto = 0;
        $mcBajo = 0;





        
        return [
            'pVenta'          => $data['pVenta'],
            'pVentaIVA'       => $pVentaIVA,
            'costo'           => $costo,
            'mc'              => $pVentaIVA - $costo,
            'porcentajeCosto' => $porcentajeCosto,
            'impuestos'       => $impuestos,
            'ventasEstimadas' => $ventasEstimadas,
            'costoEstimado'   => $costoEstimado,
            'mcEstimado'      => $mcEstimado,
            'desplazamiento'  => $desplazamiento,

            'precioPropuesto' => $cpAnterior['precio_propuesto'],
            'ls'              => $ls,
        ];
    }




}
