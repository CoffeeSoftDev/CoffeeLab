
            <?php
            if(empty($_POST['opc'])) exit(0);


            require_once('../mdl/mdl-costo-potencial.php');
            $obj = new Costopotencial;

            $encode = [];
            switch ($_POST['opc']) {
            case 'listUDN':
                    $encode = $obj->lsUDN();
                break;
            }

            echo json_encode($encode);
            ?>