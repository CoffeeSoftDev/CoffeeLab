<div class="row mb-3 d-flex justify-content-end mt-1">
</div>
<div class="row" id="containerTbIngrediente"></div>

<script src='src/js/ingredientes.js?t=<?php echo time(); ?>'></script>