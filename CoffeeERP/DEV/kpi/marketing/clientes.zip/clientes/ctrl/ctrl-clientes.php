<?php

session_start();
if (empty($_POST['opc'])) exit(0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

require_once '../mdl/mdl-clientes.php';

class ctrl extends mdl {

    function init() {
        return [
            'udn' => $this->lsUDN()
        ];
    }

    function listClientes() {
        $__row = [];
        
        $active = isset($_POST['active']) ? $_POST['active'] : 1;
        $udnId  = isset($_POST['udn_id']) && $_POST['udn_id'] !== 'all' ? $_POST['udn_id'] : null;
        $vip    = isset($_POST['vip']) && $_POST['vip']       !== 'all' ? $_POST['vip'] : null;
        
        $ls     = $this->lsClientes([$active, $udnId, $vip]);

        foreach ($ls as $key) {
            $a = [];

            $nombreCompleto = trim($key['nombre'] . ' ' . $key['apellido_paterno'] . ' ' . $key['apellido_materno']);

            $badgeVIP = $key['vip'] == 1 
                ? '<span class="px-2 py-1 rounded-md text-xs font-semibold bg-orange-400 text-white"><i class="icon-star"></i> VIP</span>' 
                : '<span class="px-2 py-1 rounded-md text-xs font-semibold bg-gray-300 text-gray-600">Regular</span>';

            if ($key['active'] == 1) {
                $a[] = [
                    'class'   => 'btn btn-sm btn-primary me-1',
                    'html'    => '<i class="icon-pencil"></i>',
                    'onclick' => 'clientes.editCliente(' . $key['id'] . ')'
                ];

                $a[] = [
                    'class'   => 'btn btn-sm btn-danger',
                    'html'    => '<i class="icon-toggle-on"></i>',
                    'onclick' => 'clientes.statusCliente(' . $key['id'] . ', ' . $key['active'] . ')'
                ];
            } else {
                $a[] = [
                    'class'   => 'btn btn-sm btn-outline-success',
                    'html'    => '<i class="icon-toggle-off"></i>',
                    'onclick' => 'clientes.statusCliente(' . $key['id'] . ', ' . $key['active'] . ')'
                ];
            }

            $__row[] = [
                'id' => $key['id'],
                'Nombre Completo' => $nombreCompleto,
                'Teléfono' => $key['telefono'],
                'Correo' => $key['correo'] ?? '-',
                'Unidad de Negocio' => $key['udn_nombre'],
                'Estatus' => renderStatus($key['active']),
                'VIP' => ['html' => $badgeVIP, 'class' => 'text-center'],
                'a' => $a
            ];
        }

        return [
            'row' => $__row,
            'ls' => $ls
        ];
    }

    function getCliente() {
        $status = 500;
        $message = 'Error al obtener los datos del cliente';
        $data = null;

        if (empty($_POST['id'])) {
            return [
                'status' => 400,
                'message' => 'ID de cliente no proporcionado',
                'data' => null
            ];
        }

        $cliente = $this->getClienteById($_POST['id']);

        if ($cliente) {
            $status = 200;
            $message = 'Cliente obtenido correctamente';
            $data = $cliente;
        } else {
            $status = 404;
            $message = 'Cliente no encontrado';
        }

        return [
            'status' => $status,
            'message' => $message,
            'data' => $data
        ];
    }

    function addCliente() {
        $status = 500;
        $message = 'No se pudo registrar el cliente';

       

        $_POST['fecha_creacion'] = date('Y-m-d H:i:s');
        $_POST['active']         = 1;
        $_POST['vip']            = isset($_POST['vip']) && $_POST['vip'] == 1 ? 1 : 0;



        $clienteId = $this->createCliente($this->util->sql($_POST));
         if ($clienteId) {
           
            $status = 200;
            $message = 'Cliente agregado correctamente';

        }
      
        return [
            'status' => $status,
            'message' => $message
        ];
    }

    function editCliente() {
        $status = 500;
        $message = 'Error al actualizar el cliente';



        // $exists = $this->existsClienteByPhone($_POST['telefono'], $_POST['id']);
        // if ($exists > 0) {
        //     return [
        //         'status' => 409,
        //         'message' => 'Ya existe otro cliente registrado con ese número de teléfono'
        //     ];
        // }

        // $_POST['vip'] = isset($_POST['vip']) && $_POST['vip'] == 1 ? 1 : 0;

        $values  = $this->util->sql($_POST, 1);
        $updated = $this->updateCliente($values);

        if ($updated) {
        
            $status = 200;
            $message = 'Cliente actualizado correctamente';
        }

        return [
            'status' => $status,
            'message' => $message,
            $values
        ];
    }

    function statusCliente() {
        $status = 500;
        $message = 'No se pudo actualizar el estatus del cliente';

        if (empty($_POST['id'])) {
            return [
                'status' => 400,
                'message' => 'ID de cliente no proporcionado'
            ];
        }

        $updated = $this->updateCliente($this->util->sql($_POST, 1));

        if ($updated) {
            $status = 200;
            $message = "guardado correctamente";
        }

        return [
            'status' => $status,
            'message' => $message
        ];
    }

    function getEstadisticas() {
        $udnId = isset($_POST['udn_id']) && $_POST['udn_id'] !== 'all' ? $_POST['udn_id'] : null;

        $totalActivos = $this->getTotalClientesActivos($udnId);
        $totalVIP = $this->getTotalClientesVIP($udnId);
        $cumpleañosMes = $this->getClientesCumpleañosMes($udnId);

        return [
            'status' => 200,
            'data' => [
                'total_activos' => $totalActivos,
                'total_vip' => $totalVIP,
                'cumpleaños_mes' => count($cumpleañosMes),
                'lista_cumpleaños' => $cumpleañosMes
            ]
        ];
    }
}

function renderStatus($status) {
    switch ($status) {
        case 1:
            return '<span class="inline-flex items-center gap-2 px-4 py-1 rounded text-sm font-medium bg-green-100 text-green-700">
                        <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                        Activo
                    </span>';
        case 0:
            return '<span class="inline-flex items-center gap-2 px-4 py-1 rounded text-sm font-medium bg-red-100 text-red-700">
                        <span class="w-2 h-2 bg-red-500 rounded-full"></span>
                        Inactivo
                    </span>';
        default:
            return '<span class="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium bg-gray-100 text-gray-700">
                        <span class="w-2 h-2 bg-gray-500 rounded-full"></span>
                        Desconocido
                    </span>';
    }
}

function formatSpanishDate($date) {
    if (empty($date)) return '-';
    $timestamp = strtotime($date);
    $months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    return date('d', $timestamp) . ' ' . $months[date('n', $timestamp) - 1] . ' ' . date('Y', $timestamp);
}

$obj = new ctrl();
echo json_encode($obj->{$_POST['opc']}());
