    <!--JQUERY-->
    <script src="../src/plugin/jquery/jquery-3.7.0.min.js"></script>
    <!--BOOTSTRAP-->
    <script src="../src/plugin/bootstrap-5/js/bootstrap.min.js"></script>
    <script src="../src/plugin/bootstrap-5/js/bootstrap.bundle.js"></script>
    <!--SELECT2-->
    <script src="../src/plugin/select2/bootstrap/select2.min.js"></script>
    <!--BOOTBOX-->
    <script src="../src/plugin/bootbox.min.js"></script>
    <!-- SWEETALERT -->
    <script src="../src/plugin/sweetalert2/sweetalert2.all.min.js"></script>
    <!--DATERANGEPICKER-->
    <script src="../src/plugin/daterangepicker/moment.min.js"></script>
    <script src="../src/plugin/daterangepicker/daterangepicker.js"></script>
    <!--DATATABLES-->
    <script src="../src/plugin/datatables/datatables.min.js"></script>
    <script src="../src/plugin/datatables/dataTables.responsive.min.js"></script>
    <script src="../src/plugin/datatables/1.13.6/js/dataTables.bootstrap5.min.js"></script>
   <!-- INTRO -->
    <script src="../src/plugin/intro-js/js/intro.min.js"></script>


   <!--PERSONALIZADOS-->

    <script src="../src/js/navbar.js"></script>
    <script src="../src/js/sidebar.js"></script>

    <script src="https://15-92.com/ERP3/src/js/CoffeSoft.js?t=<?php echo time(); ?>"></script>


    <script src="https://www.plugins.erp-varoch.com/ERP/JS/complementos.js?t=1724390004"></script>
    <script src="https://15-92.com/ERP3/src/js/plugin-forms.js?t=<?php echo time(); ?>"></script>
    <script src="https://15-92.com/ERP3/src/js/plugin-table.js?t=<?php echo time(); ?>"></script>

    <!-- EXTERNOS -->

</head>
