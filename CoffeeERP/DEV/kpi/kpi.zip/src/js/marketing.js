let api = "ctrl/ctrl-ingresos.php";
let api_marketing = "ctrl/ctrl-marketing.php";
let app, ingresos, comparativa, diario, acomulados;
let udn, mkt;

$(async () => {
    mkt = await useFetch({ url: api_marketing, data: { opc: "init" } });
   
    const data = await useFetch({ url: api, data: { opc: "init" } });
    udn = data.udn;

    // Instancias.
    app = new App(api, "root");
    ingresos = new Ingresos(api, "root");
    comparativa = new ComparativaMensual(api, "root");
    diario = new PromediosDiarios(api, "root");
    acomulados = new PromediosAcomulados(api, "root");

    app.render();
    ingresos.init();
    comparativa.init();

    diario.init();
    acomulados.init();

});


class App extends Templates {
    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "Dashboard";
    }

    render() {

        this.tabs();
        this.layout()
        this.filterBar();
        // this.renderDashboard();

    }

    layout() {
        this.primaryLayout({
            parent: `container-dashboard`,
            id: 'dashboard',
            card: {
                filterBar: { class: 'w-full  rounded', id: `filterBarDashboard` },
                container: { class: 'w-full  rounded h-full mt-3 p-3 ', id: `containerDashboard` }
            }
        });
    }

    filterBar() {
        this.createfilterBar({
          parent: `filterBarDashboard`,
          data: [
            {
              opc: "select",
              id: "udn",
              lbl: "Seleccionar udn",
              class: "col-sm-3",
              data: udn,
              onchange: `app.renderDashboard()`,
            },

            {
              opc: "select",
              id: "mes",
              lbl: "Mes",
              class: "col-sm-3",
              data: moment.months().map((m, i) => ({ id: i + 1, valor: m })),
                onchange: `app.renderDashboard()`,
            },

            {
              opc: "select",
              id: "anio",
              lbl: "Año",
              class: "col-sm-3",
              data: Array.from({ length: 5 }, (_, i) => {
                const year = moment().year() - i;
                return { id: year, valor: year.toString() };
              }),
                onchange: `app.renderDashboard()`,
            },
          ],
        });

        const currentMonth = moment().month() + 1; // Mes actual (1-12)

        setTimeout(() => {
            $(`#filterBarDashboard #mes`).val(currentMonth).trigger("change");
        }, 100);
    }

    tabs() {
        this.tabLayout({
            parent: `root`,
            id: `tabs${this.PROJECT_NAME}`,
            theme: "light",
            type: "short",
            json: [
                {
                    id: "dashboard",
                    tab: "Dashboard",
                    class: "mb-1",
                    active: true,
                    onClick: () => this.renderDashboard()
                },
                {
                    id: "modIngresos",
                    tab: "Módulo ingresos",

                    onClick: () => {
                        ingresos.lsIngresos()
                    }

                },
                {
                    id: "comparativasMensuales",
                    tab: "Comparativas mensuales",
                    onClick: () => {
                        comparativa.lsComparativa()
                    }
                },
                // {
                //     id: "promediosDiarios",
                //     tab: "Promedios diarios",


                //     onClick: () => {

                //     }
                // },
                {
                    id: "promediosAcumulados",
                    tab: "Promedios acomulados",
                    onClick: () => {

                    }
                },
            ]
        });
    }


    async renderDashboard() {

        let udn   = $('#filterBarDashboard #udn').val();
        let month = $('#filterBarDashboard #mes').val();
        let year  = $('#filterBarDashboard #anio').val();

        let mkt = await useFetch({
          url: api_marketing,
          data: {
            opc: "init",
            udn: udn,
            month: month,
            year: year,
          },
        });
        
        $("#containerDashboard").html(`
            <div class=" font-sans  mx-auto">

            <!-- Header -->
            <div class="flex items-center justify-between">
                <div>
                <h1 class="text-2xl font-bold text-[#103B60]">Dashboard de Ventas</h1>
                <p class="text-sm text-gray-600 mt-1 ">Análisis anual, por período y por hora</p>
                </div>
            </div>


            <!-- KPIs -->
            <div class="" id="kpiDashboard"></div>

            <!-- Resto del dashboard (gráficas, tabla, etc.) -->
            <h2 class="text-lg font-semibold text-[#103B60] mt-3">
                Promedios Diarios (Comparativa Anual)
            </h2>

            <div class="grid lg:grid-cols-2 gap-4 mb-2">
            <!-- Cheque Promedio A & B -->
            <div class="bg-white rounded-lg shadow-sm p-3 !h-auto" id="containerChequePro"></div>

            <!-- Ventas por Categoría -->
            <div class="bg-white rounded-lg shadow-sm p-3 " id="cardCategorias">
              <div id="containerVentas" class="overflow-auto max-h-[90vh]"></div>
            </div>
            </div>

            <div class="bg-white rounded-xl shadow overflow-auto">
                <div class="p-4 border-b border-gray-200 text-lg font-semibold text-[#103B60]">
                Qué se vendió
                </div>
             
            </div>
        `);

        // KPIs visuales
        this.infoCard({
          parent: "kpiDashboard",
          theme: "light",
          json: [
            {
              id: "kpiDia",
              title: "Venta del día de ayer",
              data: {
                value: mkt.ventas_dia,
                description: "+12% vs ayer",
                color: "text-[#8CC63F]",
              },
            },
            {
              id: "kpiMes",
              title: "Venta del Mes",
              data: {
                value: mkt.ventas_mes,
                description: "+8% vs mes anterior",
                color: "text-green-800",
              },
            },
            {
              title: "Clientes",
              data: {
                  value: mkt.clientes_mes,
                description: "+5% vs período anterior",
                color: "text-[#103B60]",
              },
            },
            {
              id: "kpiCheque",
              title: "Cheque Promedio",
              data: {
                  value: mkt.resumen_mes,
                description: "-2% vs período anterior",
                color: "text-red-600",
              },
            },
          ],
        });

        // Fecha actual para el resumen de horas
        const fechaHoy = new Date().toLocaleDateString("es-MX");
        $("#fechaHoy").text(fechaHoy);

        this.chequeComparativo({
            data: mkt.barras.data
        });

        this.comparativaCategorias()
    }

    infoCard(options) {
        const defaults = {
            parent: "root",
            id: "infoCardKPI",
            class: "",
            theme: "light", // light | dark
            json: [],
            data: {
                value: "0",
                description: "",
                color: "text-gray-800"
            },
            onClick: () => { }
        };

        const opts = Object.assign({}, defaults, options);

        const isDark = opts.theme === "dark";

        const cardBase = isDark
            ? "bg-[#1F2A37] text-white rounded-xl shadow"
            : "bg-white text-gray-800 rounded-xl shadow";

        const titleColor = isDark ? "text-gray-300" : "text-gray-600";
        const descColor = isDark ? "text-gray-400" : "text-gray-500";

        const renderCard = (card, i = "") => {
            const box = $("<div>", {
                id: `${opts.id}_${i}`,
                class: `${cardBase} p-4`
            });

            const title = $("<p>", {
                class: `text-sm ${titleColor}`,
                text: card.title
            });

            const value = $("<p>", {
                id: card.id || "",
                class: `text-2xl font-bold ${card.data?.color || "text-white"}`,
                text: card.data?.value
            });

            const description = $("<p>", {
                class: `text-xs mt-1 ${card.data?.color || descColor}`,
                text: card.data?.description
            });

            box.append(title, value, description);
            return box;
        };

        const container = $("<div>", {
            id: opts.id,
            class: `grid grid-cols-2 md:grid-cols-4 gap-4 ${opts.class}`
        });

        if (opts.json.length > 0) {
            opts.json.forEach((item, i) => {
                container.append(renderCard(item, i));
            });
        } else {
            container.append(renderCard(opts));
        }

        $(`#${opts.parent}`).html(container);
    }

  

    chequeComparativo(options) {
        const defaults = {
            parent: "containerChequePro",
            id: "chart",
            title: "Comparativa Cheque Promedio",
            class: "border p-4 rounded-xl",
            data: {},
            json: [],
            onShow: () => { },
        };

        const opts = Object.assign({}, defaults, options);

        const container = $("<div>", { class: opts.class });

        const title = $("<h2>", {
            class: "text-lg font-bold mb-2",
            text: opts.title
        });

        const canvas = $("<canvas>", {
            id: opts.id,
            class: "w-full h-[300px]"
        });

        container.append(title, canvas);
        $('#' + opts.parent).html(container);

        const anioA = new Date().getFullYear();
        const anioB = anioA - 1;

        const dCheque = {
            labels: ["A&B", "Alimentos", "Bebidas"],
            A: [673.18, 613.0, 54.6],
            B: [640.25, 590.5, 49.75]
        };

        const ctx = document.getElementById(opts.id).getContext("2d");

        if (window._chq) window._chq.destroy();

        window._chq = new Chart(ctx, {
            type: "bar",
            data: {
                labels: opts.data.labels,
                datasets: [
                    {
                        label: `Año ${anioA}`,
                        data: opts.data.A,
                        backgroundColor: "#103B60"
                    },
                    {
                        label: `Año ${anioB}`,
                        data: opts.data.B,
                        backgroundColor: "#8CC63F"
                    }
                ]
            },
            options: {
                responsive: true,
                animation: {
                    onComplete: function () {
                        const chart = this;
                        const ctx = chart.ctx;
                        ctx.font = "12px sans-serif";
                        ctx.textAlign = "center";
                        ctx.textBaseline = "bottom";
                        ctx.fillStyle = "#000";

                        chart.data.datasets.forEach(function (dataset, i) {
                            const meta = chart.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                const value = dataset.data[index];
                                const label = typeof formatPrice === "function" ? formatPrice(value) : value;
                                ctx.fillText(label, bar.x, bar.y - 5);
                            });
                        });
                    }
                },
                plugins: {
                    legend: { position: "bottom" },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => `${ctx.dataset.label}: ${formatPrice(ctx.parsed.y)}`
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: (v) => formatPrice(v)
                        }
                    }
                }
            }
        });
    }


    comparativaCategorias(options) {
        const defaults = {
            parent: "containerVentas",
            id: "chartCategorias",
            title: "Comparativa de Categorías",
            class: "bg-white p-4 rounded-xl shadow-md",
            data: {},
            json: {
                labels: ["Bebidas", "Snacks", "Frutas"],
                A: [5000, 3200, 1800],
                B: [4700, 3000, 1600]
            },
            anioA: new Date().getFullYear(),
            anioB: new Date().getFullYear() - 1,
            onShow: () => { }
        };

        const opts = Object.assign({}, defaults, options);

        const rows = opts.json.labels.length;
        const canvasHeight = Math.max(rows * 26 + 50, 300);

        const container = $("<div>", {
            class: opts.class
        });

        const title = $("<h3>", {
            class: "text-sm font-semibold text-[#103B60] mb-2",
            text: opts.title
        });

        // 🔁 Nuevo wrapper para canvas con altura controlada
        const canvasWrapper = $("<div>", {
            class: "relative w-full",
            css: {
                height: `${canvasHeight}px`
            }
        });

        const canvas = $("<canvas>", {
            id: opts.id,
            class: "w-full"
        });

        canvasWrapper.append(canvas);
        container.append(title, canvasWrapper);
        $(`#${opts.parent}`).html(container);

        if (window._cat) window._cat.destroy();

        window._cat = new Chart(document.getElementById(opts.id).getContext("2d"), {
            type: "bar",
            data: {
                labels: opts.json.labels,
                datasets: [
                    {
                        label: `Año ${opts.anioA}`,
                        data: opts.json.A,
                        backgroundColor: "#103B60"
                    },
                    {
                        label: `Año ${opts.anioB}`,
                        data: opts.json.B,
                        backgroundColor: "#8CC63F"
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                indexAxis: "y",
                plugins: {
                    legend: { position: "bottom" },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => `${ctx.dataset.label}: ${formatPrice(ctx.parsed.x)}`
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            callback: (v) => formatPrice(v),
                            font: { size: 11 }
                        },
                        grid: { display: true }
                    },
                    y: {
                        ticks: {
                            autoSkip: false,
                            font: { size: 11 }
                        },
                        grid: { display: false }
                    }
                }
            }
        });

        if (typeof opts.onShow === "function") opts.onShow();
    }



}

class Ingresos extends App {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "Ingresos";
    }

    init() {
        this.layout();
        this.filterBar();
        this.lsIngresos();
    }

    layout() {
        this.primaryLayout({
            parent: `container-modIngresos`,
            id: this.PROJECT_NAME,
            card: {
                filterBar: { class: 'w-full  border-b pb-2 ', id: `filterBar${this.PROJECT_NAME}` },
                container: { class: 'w-full my-2 h-full ', id: `container${this.PROJECT_NAME}` }
            }
        });
    }

    filterBar() {
        this.createfilterBar({
            parent: `filterBar${this.PROJECT_NAME}`,
            data: [
                {
                    opc: "select",
                    id: "udn",
                    lbl: "Seleccionar udn",

                    class: "col-sm-3",
                    data: udn,
                    onchange: `ingresos.lsIngresos()`,
                },
                {
                    opc: "select",
                    id: "anio",
                    lbl: "Año",
                    class: "col-sm-3",
                    data: Array.from({ length: 5 }, (_, i) => {
                        const year = moment().year() - i;
                        return { id: year, valor: year.toString() };
                    }),
                    onchange: `ingresos.lsIngresos()`,

                },
                {
                    opc: "select",
                    id: "mes",
                    lbl: "Mes",
                    class: "col-sm-3",
                    data: moment.months().map((m, i) => ({ id: i + 1, valor: m })),
                    onchange: `ingresos.lsIngresos()`,

                },

                {
                    opc: "select",
                    id: "type",
                    lbl: "Consultar",
                    class: "col-sm-3",
                    data: [
                        { id: "3", valor: "Promedios Diarios" },
                        { id: "1", valor: " Ingresos por día" },
                        { id: "2", valor: "Captura de ingresos" },
                    ],
                    onchange: `ingresos.lsIngresos()`,
                },
            ],
        });

        const currentMonth = moment().month() + 1; // Mes actual (1-12)

        setTimeout(() => {
            $(`#filterBar${this.PROJECT_NAME} #mes`).val(currentMonth).trigger("change");
        }, 100);
    }

    lsIngresos() {

        const monthText = $("#filterBarIngresos #mes option:selected").text();

        $("#containerIngresos").html(`
            <div class="px-2 pt-2 pb-2">
                <h2 class="text-2xl font-semibold ">📦 VENTAS DIARIAS</h2>
                <p class="text-gray-400">Consultar y capturar ventas diaria por unidad de negocio (ingresos)</p>
            </div>

            <div id="container-table-ingresos"></div>
        `);

        this.createTable({
            parent: "container-table-ingresos",
            idFilterBar: `filterBarIngresos`,
            data: { opc: 'list', monthText: monthText },
            coffeesoft: true,
            conf: { datatable: false, pag: 15 },
            attr: {
                id: "tbIngresos",
                theme: 'corporativo',
                center: [2],
                right: [3, 4, 6]
            },

        });
    }


}

class ComparativaMensual extends App {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "ComparativaMensual";
    }

    init() {
        this.layout();
        this.filterBar();
        this.lsComparativa();
    }

    layout() {
        this.primaryLayout({
            parent: `container-comparativasMensuales`,
            id: this.PROJECT_NAME,
            card: {
                filterBar: { class: 'w-full  border-b pb-2 ', id: `filterBar${this.PROJECT_NAME}` },
                container: { class: 'w-full my-2 h-full ', id: `container${this.PROJECT_NAME}` }
            }
        });
    }

    filterBar() {
        this.createfilterBar({
            parent: `filterBar${this.PROJECT_NAME}`,
            data: [
                {
                    opc: "select",
                    id: "udn",
                    lbl: "UDN:",
                    class: "col-sm-3",
                    data: udn,
                    onchange: `ingresos.lsIngresos()`,
                },
                {
                    opc: "select",
                    id: "anio",
                    lbl: "Año",
                    class: "col-sm-3",
                    data: [
                        { id: "2025", valor: "2025" },
                        { id: "2024", valor: "2024" },
                        { id: "2023", valor: "2023" },

                    ],
                    onchange: `comparativa.lsComparativa()`,

                },
                {
                    opc: "select",
                    id: "mes",
                    lbl: "Mes",
                    class: "col-sm-3",
                    data: moment.months().map((m, i) => ({ id: i + 1, valor: m })),
                    onchange: `comparativa.lsComparativa()`,

                },

                {
                    opc: "select",
                    id: "type",
                    lbl: "Consultar",
                    class: "col-sm-3",
                    data: [
                        { id: "1", valor: "Consulta de promedios" },
                        { id: "2", valor: "Consulta de ingresos" },
                    ],
                    onchange: `comparativa.lsComparativa()`,
                },
            ],
        });

        const currentMonth = moment().month() + 1; // Mes actual (1-12)

        setTimeout(() => {
            $(`#filterBar${this.PROJECT_NAME} #mes`).val(currentMonth).trigger("change");
        }, 100);
    }

    lsComparativa() {

        $(`#container${this.PROJECT_NAME}`).html(`
            <div class="px-2 pt-2 pb-2">
                <h2 class="text-2xl font-semibold ">📦 Comparativas Mensuales </h2>
                <p class="text-gray-400">Consulta las ventas (ingresos) y el cheque promedio (Promedios) mensual contra el año seleccionado. </p>
            </div>


            <div id="container-table-comparativa"></div>
        `);

        this.createTable({
            parent: "container-table-comparativa",
            idFilterBar: `filterBar${this.PROJECT_NAME}`,
            data: { opc: 'listComparative' },
            coffeesoft: true,
            conf: { datatable: false, pag: 15 },
            attr: {
                id: "tbIngresos",
                theme: 'corporativo',
                center: [1, 2, 3],
                right: [6]
            },

        });
    }


}

class PromediosDiarios extends App {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "promediosDiarios";
    }

    render() {

        this.layout();
    }

    init() {

        this.layout();
        this.filterBar();
        // this.lsComparativa();
    }


    layout() {

        this.primaryLayout({
            parent: `container-${this.PROJECT_NAME}`,
            id: this.PROJECT_NAME,
            card: {
                filterBar: { class: 'w-full  border-b pb-2 ', id: `filterBar${this.PROJECT_NAME}` },
                container: { class: 'w-full my-2 h-full ', id: `container${this.PROJECT_NAME}` }
            }
        });
    }

    filterBar() {

        this.createfilterBar({
            parent: `filterBar${this.PROJECT_NAME}`,
            data: [
                {
                    opc: "select",
                    id: "udn",
                    lbl: "UDN:",
                    class: "col-sm-3",
                    data: udn,
                    onchange: `ingresos.lsIngresos()`,
                },
                {
                    opc: "select",
                    id: "anio",
                    lbl: "Año",
                    class: "col-sm-3",
                    data: [
                        { id: "2025", valor: "2025" },
                        { id: "2024", valor: "2024" },
                        { id: "2023", valor: "2023" },

                    ],
                    onchange: `comparativa.lsComparativa()`,

                },
                {
                    opc: "select",
                    id: "mes",
                    lbl: "Mes",
                    class: "col-sm-3",
                    data: moment.months().map((m, i) => ({ id: i + 1, valor: m })),
                    onchange: `comparativa.lsComparativa()`,

                },

                {
                    opc: "select",
                    id: "type",
                    lbl: "Consultar",
                    class: "col-sm-3",
                    data: [
                        { id: "1", valor: "Consulta de promedios" },
                        { id: "2", valor: "Consulta de ingresos" },
                    ],
                    onchange: `comparativa.lsComparativa()`,
                },
            ],
        });
    }

}

class PromediosAcomulados extends App {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "promediosAcumulados";
    }

    init() {
        this.layout();
        this.filterBar();
        this.ls();
    }

    layout() {
        this.primaryLayout({
            parent: `container-promediosAcumulados`,
            id: this.PROJECT_NAME,
            card: {
                filterBar: { class: 'w-full  border-b pb-2 ', id: `filterBar${this.PROJECT_NAME}` },
                container: { class: 'w-full my-2 h-full ', id: `container${this.PROJECT_NAME}` }
            }
        });
    }

    filterBar() {
        const currentMonth = moment().month(); // Índice de mes actual (0-11)

        this.createfilterBar({
            parent: `filterBar${this.PROJECT_NAME}`,
            data: [
                {
                    opc: "select",
                    id: "udn",
                    lbl: "Seleccionar udn",
                    class: "col-sm-3",
                    data: udn,
                    onchange: `acomulados.ls()`,
                },
                {
                    opc: "select",
                    id: "anio",
                    lbl: "Año",
                    class: "col-sm-3",
                    data: Array.from({ length: 5 }, (_, i) => {
                        const year = moment().year() - i;
                        return { id: year, valor: year.toString() };
                    }),
                    onchange: `acomulados.ls()`,
                },
                {
                    opc: "select",
                    id: "mes",
                    lbl: "Mes",
                    class: "col-sm-3",
                    data: moment.months().map((m, i) => ({
                        id: i + 1,
                        valor: m,
                        selected: i === currentMonth
                    })),
                    onchange: `acomulados.ls()`,
                },
            ],
        });

        // initialized.
        setTimeout(() => {
            $(`#filterBar${this.PROJECT_NAME} #mes`).val(currentMonth + 1).trigger("change");
        }, 100);
    }




    ls() {

        $(`#container${this.PROJECT_NAME}`).html(`
            <div class="px-2 pt-2 pb-2">
                <h2 class="text-2xl font-semibold ">📦Ch </h2>
                <p class="text-gray-400">
                Consulta los promedios acomulados del año seleccionado, hasta el mes seleccionado.
                </p>
            </div>


            <div id="container-table-acomulados"></div>
        `);

        this.createTable({
            parent: "container-table-acomulados",
            idFilterBar: `filterBar${this.PROJECT_NAME}`,
            data: { opc: 'listAcomulados' },
            coffeesoft: true,
            conf: { datatable: false, pag: 15 },
            attr: {
                id: "tbI",
                theme: 'corporativo',
                center: [1, 2, 3],
                right: [6]
            },

        });
    }

}
